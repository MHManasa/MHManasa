var heading = document.getElementById('head');
var health = 10
health=1
if (health<2){
    heading.style.color = 'red'
}